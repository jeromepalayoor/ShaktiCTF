use rand::{Rng,SeedableRng};
use rand::rngs::StdRng;
use std::time::SystemTime;


fn randseed() -> StdRng {
    let time = SystemTime::now().duration_since(SystemTime::UNIX_EPOCH)
        .expect("Broken Time!")
        .as_secs();
    return StdRng::seed_from_u64(time);
}
fn change(st :String)-> String{
    let  mut arr: Vec<char> = st.chars().collect();
     let mut i=0;
    while i<=arr.len()-1{
    	let v1=char::from_u32(arr[i] as u32+0x3);
    	arr[i]=v1.unwrap();
    	i=i+1;
    }
    let  s: String = arr.into_iter().collect();
	return s;
}
fn rand_xor(input : String) -> String {
    let mut rd = randseed();
    return input
        .chars()
        .into_iter()
        .map(|c| format!("{:02x}", (c as u8 ^ rd.gen::<u8>())))
        .collect::<Vec<String>>()
        .join("");
}

fn main() -> std::io::Result<()> {
    let mut flag=String::new();
	println!("Enter the flag : " );
	std::io::stdin().read_line(&mut flag).unwrap();
    let mess = &flag[10..37];
    let fin=change(mess.to_string());
    flag.replace_range(10..37,&fin);
    let xored = rand_xor(flag);
    println!("{}", xored);
    Ok(())
}


